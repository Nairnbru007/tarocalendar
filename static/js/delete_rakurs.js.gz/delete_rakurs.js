			    if ($('#digits_start_year_sum_1').attr('value') == $('#rakurs_right_1').attr('value')){
					$('#rakurs_right_1').attr('value', '');
					$('#rakurs_right_1').css("background", "#374151");
					sessionStorage.setItem('value_down_1', ($('#rakurs_right_1').attr('value')));
   				}
				if ($('#digits_start_year_sum_1').attr('value') == $('#rakurs_right_2').attr('value')){
					$('#rakurs_right_2').attr('value', '');
					$('#rakurs_right_2').css("background", "#374151");
					sessionStorage.setItem('value_down_2', ($('#rakurs_right_2').attr('value')));
   				}
				if ($('#digits_start_year_sum_1').attr('value') == $('#rakurs_right_3').attr('value')){
					$('#rakurs_right_3').attr('value', '');
					$('#rakurs_right_3').css("background", "#374151");
					sessionStorage.setItem('value_down_3', ($('#rakurs_right_3').attr('value')));
   				}
				if ($('#digits_start_year_sum_1').attr('value') == $('#rakurs_right_4').attr('value')){
					$('#rakurs_right_4').attr('value', '');
					$('#rakurs_right_4').css("background", "#374151");
					sessionStorage.setItem('value_down_4', ($('#rakurs_right_4').attr('value')));
   				}
				if ($('#digits_start_year_sum_1').attr('value') == $('#rakurs_right_5').attr('value')){
					$('#rakurs_right_5').attr('value', '');
					$('#rakurs_right_5').css("background", "#374151");
					sessionStorage.setItem('value_down_5', ($('#rakurs_right_5').attr('value')));
   				}
				if ($('#digits_start_year_sum_1').attr('value') == $('#rakurs_right_6').attr('value')){
					$('#rakurs_right_6').attr('value', '');
					$('#rakurs_right_6').css("background", "#374151");
					sessionStorage.setItem('value_down_6', ($('#rakurs_right_6').attr('value')));
   				}
				if ($('#digits_start_year_sum_1').attr('value') == $('#rakurs_right_7').attr('value')){
					$('#rakurs_right_7').attr('value', '');
					$('#rakurs_right_7').css("background", "#374151");
					sessionStorage.setItem('value_down_7', ($('#rakurs_right_7').attr('value')));
   				}
   				if ($('#digits_start_year_sum_1').attr('value') == $('#rakurs_right_8').attr('value')){
					$('#rakurs_right_8').attr('value', '');
					$('#rakurs_right_8').css("background", "#374151");
					sessionStorage.setItem('value_down_8', ($('#rakurs_right_8').attr('value')));
   				}
   				if ($('#digits_start_year_sum_1').attr('value') == $('#rakurs_right_9').attr('value')){
					$('#rakurs_right_9').attr('value', '');
					$('#rakurs_right_9').css("background", "#374151");
					sessionStorage.setItem('value_down_9', ($('#rakurs_right_9').attr('value')));
   				}
				$('#digits_start_year_sum_1').attr('value', sessionStorage.getItem('value_up_3'));
				$('#digits_start_year_sum_1').attr('value', '');
				$('#digits_start_year_sum_1').css("background", "#374151");
   				$('#rakurs_right_1').attr('value', ' {{ rakurs_right_1 }} ');
   				$('#rakurs_right_2').attr('value', ' {{ rakurs_right_2 }} ');
   				$('#rakurs_right_3').attr('value', ' {{ rakurs_right_3 }} ');
   				$('#rakurs_right_4').attr('value', ' {{ rakurs_right_4 }} ');
   				$('#rakurs_right_5').attr('value', ' {{ rakurs_right_5 }} ');
   				$('#rakurs_right_6').attr('value', ' {{ rakurs_right_6 }} ');
   				$('#rakurs_right_7').attr('value', ' {{ rakurs_right_7 }} ');
   				$('#rakurs_right_8').attr('value', ' {{ rakurs_right_8 }} ');
   				$('#rakurs_right_9').attr('value', ' {{ rakurs_right_9 }} ');
   				$('#rakurs_right_1').css("background-color", color_rakurs_right_1);
   				$('#rakurs_right_2').css("background-color", color_rakurs_right_2);
   				$('#rakurs_right_3').css("background-color", color_rakurs_right_3);
   				$('#rakurs_right_4').css("background-color", color_rakurs_right_4);
   				$('#rakurs_right_5').css("background-color", color_rakurs_right_5);
   				$('#rakurs_right_6').css("background-color", color_rakurs_right_6);
   				$('#rakurs_right_7').css("background-color", color_rakurs_right_7);
   				$('#rakurs_right_8').css("background-color", color_rakurs_right_8);
   				$('#rakurs_right_9').css("background-color", color_rakurs_right_9);
   				$('#rakurs_right_2').css("background-color", color_rakurs_right_2);
   				sessionStorage.setItem('value_up_3', ($('#digits_start_year_sum_1').attr('value')));
   				sessionStorage.setItem('value_down_1', ($('#rakurs_right_1').attr('value')));
   				sessionStorage.setItem('value_down_2', ($('#rakurs_right_2').attr('value')));
   				sessionStorage.setItem('value_down_3', ($('#rakurs_right_3').attr('value')));
   				sessionStorage.setItem('value_down_4', ($('#rakurs_right_4').attr('value')));
   				sessionStorage.setItem('value_down_5', ($('#rakurs_right_5').attr('value')));
   				sessionStorage.setItem('value_down_6', ($('#rakurs_right_6').attr('value')));
   				sessionStorage.setItem('value_down_7', ($('#rakurs_right_7').attr('value')));
   				sessionStorage.setItem('value_down_8', ($('#rakurs_right_8').attr('value')));
   				sessionStorage.setItem('value_down_9', ($('#rakurs_right_9').attr('value')));
				}